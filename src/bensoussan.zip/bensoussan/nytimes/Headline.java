package bensoussan.nytimes;

public class Headline {

	private String main;
	private String print_headline;

	public String getMain() {
		return main;
	}

	public String getPrint_headline() {
		return print_headline;
	}

}
