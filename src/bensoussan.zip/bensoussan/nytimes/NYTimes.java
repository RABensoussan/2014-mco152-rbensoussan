package bensoussan.nytimes;

public class NYTimes {

	private Response response;
	private String status;
	private String copyright;
	
	public NYTimes(){}

	public Response getResponse() {
		return response;
	}

	public String getStatus() {
		return status;
	}

	public String getCopyright() {
		return copyright;
	}
	
}
