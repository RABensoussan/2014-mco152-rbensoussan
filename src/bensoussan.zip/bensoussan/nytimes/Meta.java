package bensoussan.nytimes;

public class Meta {

	public Meta(){
		
	}
}
