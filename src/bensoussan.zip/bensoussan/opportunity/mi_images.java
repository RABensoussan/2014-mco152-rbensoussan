package bensoussan.opportunity;

public class mi_images {

	private images[] images;

	public images[] getImages() {
		return images;
	}

}
