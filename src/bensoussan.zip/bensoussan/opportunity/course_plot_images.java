package bensoussan.opportunity;

public class course_plot_images {

	private images[] images;

	public images[] getImages() {
		return images;
	}
}
