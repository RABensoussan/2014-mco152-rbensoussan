package bensoussan.opportunity;

public class rcam_images {

	private images[] images;

	public images[] getImages() {
		return images;
	}
}
