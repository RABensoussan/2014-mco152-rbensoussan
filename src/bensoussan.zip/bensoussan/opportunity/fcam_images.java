package bensoussan.opportunity;

public class fcam_images {

	private images[] images;

	public images[] getImages() {
		return images;
	}
}
