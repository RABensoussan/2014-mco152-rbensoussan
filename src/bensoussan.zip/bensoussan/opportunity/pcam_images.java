package bensoussan.opportunity;

public class pcam_images {

	private images[] images;

	public images[] getImages() {
		return images;
	}
}
