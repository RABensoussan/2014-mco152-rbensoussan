package bensoussan.opportunity;

public class images {

	private String imageid;
	private String url;

	public String getImageid() {
		return imageid;
	}

	public String getUrl() {
		return url;
	}

}
