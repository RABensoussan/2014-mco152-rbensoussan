package bensoussan.tetris;

public class Square {

	
	
}
