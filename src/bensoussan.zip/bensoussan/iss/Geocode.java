package bensoussan.iss;

public class Geocode {

	private Results[] results;

	public Results[] getResults() {
		return results;
	}
}
