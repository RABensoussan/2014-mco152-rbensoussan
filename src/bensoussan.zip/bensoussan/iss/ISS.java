package bensoussan.iss;

public class ISS {

	private Response[] response;

	public Response[] getResponse() {
		return response;
	}

}
