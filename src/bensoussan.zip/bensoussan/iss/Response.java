package bensoussan.iss;

public class Response {

	private long risetime;
	private int duration;

	public long getRisetime() {
		return risetime;
	}

	public int getDuration() {
		return duration;
	}

}
